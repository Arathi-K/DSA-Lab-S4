#include<stdio.h>
#include<stdlib.h>
struct Stack
{
    int top;
    unsigned n;
    int* arrA;
};
typedef struct Stack *stack;
int isEMPTY(stack S)
{
    if(S->top==-1)
        return 1;
    else 
        return 0;
}
int isFULL(stack S)
{
    if(S->top==S->n-1)
        return 1;
    else 
        return 0;
}
void ALLOCATE(stack S)
{
	S->n=2*S->n;
	int* arrB=(int*)malloc(S->n*sizeof(int));
	for(int i=0;i<S->n;i++)
		arrB[i]=S->arrA[i];
	free(S->arrA);
	S->arrA=arrB;
}
void PUSH(stack S,int k)
{
	//printf("S->top=%d, S->n-1 =%d\n",S->top,(S->n)-1);
       if(isFULL(S)==1)
       {
       	printf("1\n");
       	ALLOCATE(S); 
       }
        S->top=S->top+1;
        S->arrA[S->top]=k;
}
char POP(stack S)
{
    if(isEMPTY(S)==0)//stack not empty
    {
        int r=S->arrA[S->top];
        S->top--;
	return r;
    }
    else return -1;
}		   
void main()
{
    int key;
    char ch;
    stack S=(stack)malloc(sizeof(stack));
    S->arrA=(int*)malloc(S->n*sizeof(int));
    scanf("%d",&S->n);
    S->top=-1;
    while(1)
    {
    	scanf("%c",&ch);
    	switch(ch)
    	{
    	case 'i':scanf("%d",&key);
    		//printf("key is %d ",key);
    		PUSH(S,key);
    		break;
    	case 'd':printf("%d\n",POP(S));
    		break;
    	case 't':exit(0);
    	}
    }
}
