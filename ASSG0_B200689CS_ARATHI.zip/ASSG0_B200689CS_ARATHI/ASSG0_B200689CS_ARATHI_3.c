#include<stdio.h>
#include<stdlib.h>
#include <string.h>

struct node
{
    int key;
    struct node *next; 
};
typedef struct node *node;
struct LL
{
    node head; 
};
typedef struct LL *LL;
node CREATE_NODE(int x)
{
    node temp;
    temp=(node)malloc(sizeof(struct node));
    temp->key=x;
    temp->next=NULL;
    return temp;
}
void LIST_INSERT_TAIL(LL L,node x)
{  
    node nowat= L->head;
    if(nowat!=NULL)
    {  
        while(nowat->next!=NULL)
            nowat=nowat->next;
        nowat->next=x;
    }
    else 
        L->head=x;
}
int NUMBER_OF_ELEMENTS(LL L)
{
	
	if(L->head==NULL)
		return 0;
	node x=L->head;
	int n=1;
	//printf("%d ",x->key);
	while(x->next!=NULL)
	{
	x=x->next;
	//printf("%d ",x->key);
	n++;
	}
	//printf("n=%d\n",n);
	return n;
}
	
node kLast(LL L,int k)
{
	
	int n=NUMBER_OF_ELEMENTS(L);
	if(k<=n)
	{
		node x=L->head;
		int pos=n-k+1;
		//printf("pos=%d\n",pos);
		for(int i=1;i<pos;i++)
			x=x->next;
		//now x= node at pos
		return x;
	}
	else
	{
		printf("-1");
		exit(0);
	}
}
LL Extract_elements(LL L,char str[])
{
 int num;
 int len=strlen(str)-1;
 node x=NULL;
 int i=0;
	while(i<len)
	{
		/*num=0;
		    while(str[i]!=' '||str[i]!='\0')  
		    {
		        num = num*10 + ((int)str[i]-48);
		        printf("%d\n",num);
		        i++;
		    }
		     x=CREATE_NODE(num);
		     printf("%d\n",x->key);
               LIST_INSERT_TAIL(L,x);*/
               if(str[i]!=' ')  
		    {
			num = 0;
			while(str[i]!=' ' && i<len)
			{	      
		        num = num*10 +((int)str[i]-48);
		        i++;
		        }
		    //printf("num..%d ",num);
		    x=CREATE_NODE(num);
		    LIST_INSERT_TAIL(L,x);
		   }
		   i++;
       }
       return L;
}
void main()
{
    int k;
   LL L=(LL)malloc(sizeof(LL));
    L->head=NULL;
   char str[10000];
   fgets(str,10000, stdin);
   //printf("str=%s\n",str);
   // printf("enter k");
    L=Extract_elements(L,str);
     scanf("%d",&k);
     printf("%d",kLast(L,k)->key);
}
