#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct Queue
{
    int head,tail,n,*arr;
};
typedef struct Queue *queue;
int isFULL(queue Q)
{
    if(Q->tail==Q->n-1)
        return 1;
    else 
        return -1;
}
int isEMPTY(queue Q)
{
    if(Q->head==Q->tail+1)
        return 1;
    else 
        return -1;
}
void ENQUEUE(queue Q,int key)
{
    if(isFULL(Q)==1)
            printf("1\n");
    else
        {
        	Q->tail++;
             Q->arr[Q->tail]=key;
        }
}
void DEQUEUE(queue Q)
{
    if(isEMPTY(Q)==1)
            printf("1\n");
    else
        {
            printf("%d\n",Q->arr[Q->head]);
            /*if(Q->head==Q->n-1)
              {
                Q->head=0;
             //   Q->tail=-1;
               }
            else*/
                Q->head=Q->head+1;
        }
}
void main()
{
    char ch;
    int key;
    queue Q=(queue)malloc(sizeof(queue));
    Q->head=0;
    Q->tail=-1;
    scanf("%d",&Q->n);
    Q->arr=(int*)malloc(Q->n*sizeof(int));
    while(1)
    {
        scanf("%c", &ch);
        switch(ch)
        {
            case 'i':
                 scanf("%d",&key);
                 ENQUEUE(Q,key);
                 break;

            case 'd':
                 DEQUEUE(Q);
                 break;

             case 'f':
                 printf("%d\n",isFULL(Q));
                 break;
            case 'e':
                 printf("%d\n",isEMPTY(Q));
                 break;
            case 't':
                 exit(0);
        }
    }
}
