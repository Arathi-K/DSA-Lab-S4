#include<stdio.h>
#include<stdlib.h>
#include <string.h>
struct node
{
	int key;
	struct node* right;
	struct node* left;
	char clr;
};
typedef struct node* node;
struct BST
{
   struct node* root; 
};
typedef struct BST* BST;
// node CREATESENTINEL()
// {
//     node x=(node)malloc(sizeof(struct node));
//     x->left=NULL;
//     x->right=NULL;
//     x->clr='B';
// }
node CREATE_NODE(int k)
{
	node x=(node)malloc(sizeof(struct node));
	x->key=k;
	x->right=NULL;
	x->left=NULL;
//     x->right=NULL;
// 	x->left=NULL;
	x->clr='R';
	return x;
} 
// int max(int a ,int b)
// {
// 	if(a>b)
// 		return a;
// 	else
// 		return b;
// }
node RotateFromLeft(node now)//y=now,x=temp1,t2=temp2
{
    node temp1,temp2;
    temp1 = now->left;
    temp2 = temp1->right;

    temp1->right = now;
    now->left = temp2;

    // now->height = max(Height(now->left), Height(now->right))+1;
    // temp1->height = max(Height(temp1->left), Height(temp1->right))+1;
     return temp1;
}
node RotateFromRight(node now)
{
     node temp1,temp2;
     temp1 = now->right;
     temp2 = temp1->left;
 
    // Perform rotation
    temp1->left = now;
    now->right = temp2;
 
    //  Update heights
    // now->height = max(Height(now->left), Height(now->right))+1;
    // temp1->height = max(Height(temp1->left), Height(temp1->right))+1;
 
    // Return new root
    return temp1;
}
node rbInsert(node root,node new)
{
	if(root==NULL)
		return new;
	if(new->key<root->key)
	{
		root->left=rbInsert(root->left,new);
		if(root->left->clr=='B')
			return root;
		else	//if child is red
		{
			if((root->left->left!=NULL&&root->left->left->clr=='R')||(root->left->right!=NULL && root->left->right->clr=='R'))//if childs child is red
			{
				if(root->right!=NULL && root->right->clr=='R')	//uncle is red ------case 1------
				{
					root->right->clr='B';	//turn uncle black
					root->left->clr='B';	//turn parent black
					root->clr='R';			//turn grandparent red
					return root;
				}
				else	//if uncle is black
				{
					if(root->left->right!=NULL && root->left->right->clr=='R')//-------case 2->zigzag
						root->left=RotateFromRight(root->left);//converted to -------case 3(straight) by left rotate
					root=RotateFromLeft(root);//right rotate at root
					root->right->clr='R';
					root->clr='B';
					return root;
					
				}
			}
			//else do nothing
			return root;
		}
	}
	else
	{
		root->right=rbInsert(root->right,new);
		if(root->right->clr=='B')
			return root;
		else	//if child is red
		{
			if((root->right->left!=NULL && root->right->left->clr=='R')||(root->right->right!=NULL && root->right->right->clr=='R'))//if childs child is red
			{
				if(root->left!=NULL && root->left->clr=='R')	//uncle is red ------case 1------
				{
					root->left->clr='B';	//turn uncle black
					root->right->clr='B';	//turn parent black
					root->clr='R';			//turn grandparent red
					return root;
				}
				else	//if uncle is black
				{
					if((root->right->left!=NULL && root->right->left->clr=='R'))//-------case 2->zigzag
						root->right=RotateFromLeft(root->right);//converted to -------case 3(straight) by right rotate
					root=RotateFromRight(root);//left rotate at root
					root->left->clr='R';
					root->clr='B';
					return root;
				}
			}
			//else do nothing
			return root;
		}
	}

}
node INSERTredBlack(node root,int key)
{
		node new=CREATE_NODE(key);
		// printf("key=%d clr=%c\n",new->key,new->clr);
		root=rbInsert(root,new);
		if(root->clr=='R')
			root->clr='B';
		return root;
}
node cla(node root,int a,int b)
{
   if(root==NULL)
   	return NULL;
   if(root->key==a ||root->key==b)
   	return root;
   node left=cla(root->left,a,b);
   node right=cla(root->right,a,b);
   if(left!=NULL &&right!=NULL)
   	return root;
   if(left==NULL &&right==NULL)
   	return NULL;
   if(left!=NULL && right==NULL)
   	return left;
   else
   	return right;
}
int distFromRoot(node root,node x)
{
	int dist=-1;
	if(root==x)
		return dist++;
	else if(x->key<root->key)
	{
		return 1+distFromRoot(root->left,x);
	}
	else if(x->key>root->key)
		return 1+distFromRoot(root->right,x);
}
int checkifbeautiful(BST T,node now,node point,int k)
{
	int distbtwnodes=distFromRoot(T->root,now)+distFromRoot(T->root,point)-2*distFromRoot(T->root,cla(T->root,now->key,point->key));
// 	printf("dist between now=%d and point =%d is %d\n",now->key,point->key,distbtwnodes);
	if (distbtwnodes==k)
	{
		if(now->clr=='B')
			return 1;
	}
	if(now->left!=NULL && checkifbeautiful(T,now->left,point,k)==1)
		return 1;
	if(now->right!=NULL && checkifbeautiful(T,now->right,point,k)==1)
		return 1;
	return 0;
}
int SUM(BST T,node present,int k)
{
	int sum=0;
	if(present!=NULL)
	{
		if(checkifbeautiful(T,T->root,present,k)==1)
		{
		    sum++;
		  //  printf("sum=%d\n",sum);
		}
		sum+=SUM(T,present->left,k);
// 		printf("sum=%d\n",sum);
		sum+=SUM(T,present->right,k);
// 		printf("sum=%d\n",sum);
	}
	return sum;
}
void main()
{
	int key,X,N;
    scanf("%d",&X);
    scanf("%d",&N);
	BST T=(BST)malloc(sizeof(struct BST));
	T->root=NULL;
	for(int i=0;i<N;i++)
	{
		scanf("%d",&key);
        T->root=INSERTredBlack(T->root,key);
    }
    printf("%d\n",SUM(T,T->root,X));
}