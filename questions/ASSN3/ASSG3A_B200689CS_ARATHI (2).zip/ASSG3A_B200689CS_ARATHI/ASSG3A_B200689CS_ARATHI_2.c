#include<stdio.h>
#include<stdlib.h>
struct node
{
	int key;
	struct node* right;
	struct node* left;
};
struct BST
{
   struct node* root; 
};
struct node* CREATE_NODE(int k)
{
	struct node* x=(struct node*)malloc(sizeof(struct node));
	x->key=k;
	x->right=NULL;
	x->left=NULL;\
	return x;
} 
void INSERT(struct BST* T,int info)
{
    //if(T->root==NULL)printf("ROOT null");
    if(T->root==NULL)
     {
           T->root=CREATE_NODE(info);
           return;
     }
    struct node* new=CREATE_NODE(info);
	struct node* now=T->root;
	//if(T->root==NULL)printf("root null");
	while(now!=NULL)
	{
		if(new->key < now->key)
        {
            if(now->left==NULL)
               {
                    now->left=new;
                    return;
               } 
            else
                now=now->left;
        }
			
		else if(new->key > now->key)
        {
            if(now->right==NULL)
               {
                    now->right=new;
                    return;
               } 
            else
                now=now->right;
        }
	}
}
int Findheight(struct node* x)
{
    if(x!=NULL)
    {
        int a=Findheight(x->left);
        int b=Findheight(x->right);
        if(a>b)
            return 1+a;
        else
            return 1+b;
    }
    return 0;
}

int findBF(struct node* root)
{
    // if(root==NULL)
    //     return 0;
    int a=Findheight(root->left);
    // printf("a=%d\n",a);
    int b=Findheight(root->right);
    //  printf("b=%d\n",b);
    return a-b;
}

int IsAVL(struct node* root)
{
    if(root!=NULL)
    {
   int bf=findBF(root);
  // int bf=-2;
    if(bf==-1||bf==0||bf==1)
    { 
        if(IsAVL(root->left)==0||IsAVL(root->right)==0)
            return 0;
        return 1;
    }
    else
        return 0;
    }
    return 1;
}
void PREORDER(struct node* x)
{
   if(x!=NULL)
   {
    printf("%d ",x->key);
    PREORDER(x->left);
    PREORDER(x->right);
   }
}
void main()
{
	char ch;
	int info;
	struct BST* T=(struct BST*)malloc(sizeof(struct BST));
	T->root=NULL;
    while(1)
	{
		scanf(" %c",&ch);

		switch(ch)
		{
    	case 'i':scanf("%d",&info);
			    INSERT(T,info);
			    break;
	    case 'p':PREORDER(T->root);
		        printf("\n");
			 break;
        case 'c':printf("%d\n",IsAVL(T->root));
                break;
		case 't':exit(0);
		}
	}
}