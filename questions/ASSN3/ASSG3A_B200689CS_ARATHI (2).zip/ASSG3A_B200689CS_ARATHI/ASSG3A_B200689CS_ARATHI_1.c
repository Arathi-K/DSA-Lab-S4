#include<stdio.h>
#include<stdlib.h>
struct node
{
	int key;
	struct node* right;
	struct node* left;
	int height;
};
typedef struct node* node;
struct BST
{
   struct node* root; 
};
typedef struct BST* BST;
node CREATE_NODE(int k)
{
	node x=(node)malloc(sizeof(struct node));
	x->key=k;
	x->right=NULL;
	x->left=NULL;
	x->height=1;
	return x;
} 
int Height(node x)
{
    if (x != NULL)
        return x->height;
    return 0;
}
node SEARCH(node now,int info)
{
	if(now==NULL || info==now->key)
		return now;
	if(info< now->key)
		return SEARCH(now->left,info);
	else 
		return SEARCH(now->right,info);
}
int max(int a ,int b)
{
	if(a>b)
		return a;
	else
		return b;
}
// node TreeMin(node given_node)
// {
// 	while(given_node->left !=NULL)
// 		given_node=given_node->left;
// 	return given_node;
// }
node TreeMax(node given_node)
{
	while(given_node->right !=NULL)
		given_node=given_node->right;
	return given_node;
}
void GetBalance(BST T, int info)
{
	node present=SEARCH(T->root,info);
	if(present!=NULL)
	{
	  printf("%d\n",Height(present->left)-Height(present->right));
	}
    else
        printf("FALSE\n");
}
void PrintTREE(node now)
{
	printf("( ");
	if(now!=NULL)
	{
	printf("%d ",now->key);
	PrintTREE(now->left);
	PrintTREE(now->right);
	}
	printf(") ");
	
}
node RotateFromLeft(node now)//y=now,x=temp1,t2=temp2
{
    node temp1,temp2;
    temp1 = now->left;
    temp2 = temp1->right;

    temp1->right = now;
    now->left = temp2;

    now->height = max(Height(now->left), Height(now->right))+1;
    temp1->height = max(Height(temp1->left), Height(temp1->right))+1;
     return temp1;
}
node RotateFromRight(node now)
{
     node temp1,temp2;
     temp1 = now->right;
     temp2 = temp1->left;
 
    // Perform rotation
    temp1->left = now;
    now->right = temp2;
 
    //  Update heights
    now->height = max(Height(now->left), Height(now->right))+1;
    temp1->height = max(Height(temp1->left), Height(temp1->right))+1;
 
    // Return new root
    return temp1;
}
node DoubleRotateFromRight(node n)
{
	n->right=RotateFromLeft(n->right);
	n=RotateFromRight(n);
	return n;
}
node DoubleRotateFromLeft(node n)
{
	n->left=RotateFromRight(n->left);
	n=RotateFromLeft(n);
	return n;
}
node INSERT(node now,int info)
{
	if(now==NULL)
	{
			now=CREATE_NODE(info);
			return now;
	}
	if (info != now->key)
	{
	    int bf;
	    if (info < now->key)
        {
        	now->left = INSERT(now->left,info);
           // PrintTREE(now);
            //printf("\n");
        	bf=Height(now->left)-Height(now->right);
           // printf("bf=%d\n",bf);
        	if(bf>1)
        	{
        		if(info < now->left->key)//outside case- left left case
        			now=RotateFromLeft(now);
				else //inside case
					now=DoubleRotateFromLeft(now);
			}
		}
   	else if (info > now->key)
        {
			now->right = INSERT(now->right,info);
			bf=Height(now->left)-Height(now->right);
			if(bf<-1)
        	{
        		if(info > now->right->key)//outside case
        			now=RotateFromRight(now);
				else //inside case
					now=DoubleRotateFromRight(now);
			}
		}
		now->height=max(Height(now->left),Height(now->right))+1;
       // printf("ht of %d is %d\n",now->key,now->height);
		
	}
    return now;
}
node DELETE(node now,int k)
{ 
    if (now == NULL)//IF TREE was empty,return null
        return now;
	if( k == now->key)//if now is the node to be deleted
	{
		node temp;
		if(now->left==NULL && now->right ==NULL)//if no children
		{
			temp=now;
			now=NULL;
			free(temp);
		}
		else if(now->left!=NULL && now->right ==NULL)//if only left child
		{
			temp=now;
			now=temp->left;
			free(temp);
		}
		else if(now->left==NULL && now->right !=NULL)//if only right child
		{
			temp=now;
			now=temp->right;
			free(temp);
		}
		else
		{
			temp=TreeMax(now->left);
			now->key=temp->key;
			now->left=DELETE(now->left,temp->key);
		}
	}
	else if(k<now->key)
		now->left=DELETE(now->left,k);
	else
		now->right=DELETE(now->right,k);
	
	if(now==NULL)
		return now;
	now->height=max(Height(now->left),Height(now->right))+1;
	int bf=Height(now->left)-Height(now->right);
	if(bf>1)
	{
		int bf_l =Height(now->left->left)-Height(now->left->right);
		if(bf_l>=0)//left-left case
			now=RotateFromLeft(now);
		else
			now=DoubleRotateFromLeft(now);
	}
	else if(bf<-1)
	{
		int bf_r =Height(now->right->left)-Height(now->right->right);
		if(bf_r<=0)//right-right case
			now=RotateFromRight(now);
		else
			now=DoubleRotateFromRight(now);
	}
	return now;
}

void main()
{
	char ch;
	int info;
	node present;
	BST T=(BST)malloc(sizeof(struct BST));
	T->root=NULL;
	while(1)
	{
		scanf(" %c",&ch);

		switch(ch)
		{
    	case 'i':scanf("%d",&info);
			    T->root=INSERT(T->root,info);
			    break;
		case 'e':exit(0);
		case 'd':scanf("%d",&info);
			 	present=SEARCH(T->root,info);
			 	if(present==NULL)
			   		 printf("FALSE\n");
			 	else
			    {
			        printf("%d\n",present->key);
			        T->root=DELETE(T->root,info);
			    }
			 	break;
		case 'p':PrintTREE(T->root);
				printf("\n");
				break;
		case 'b':scanf("%d",&info);
				 GetBalance(T,info);
				 break;
		case 's':scanf("%d",&info);
			     present=SEARCH(T->root,info);
			    if(present==NULL)
			 		printf("FALSE\n");
			    else 
			 		printf("TRUE\n");
			    break;
		}
	}
}
