#include<stdio.h>
#include<stdlib.h>
struct node {
    int key;
    int parent;
    int rank;
    // struct node* parent;
};
struct node * Hash_table(struct node *p, int m)
{
	int i;
	p = (struct node*) malloc(m * sizeof(struct node));
	for (i = 0; i < m; i++) 
        {
		p[i].key = -1;
	}
	return p;
}
struct node* make_set(struct node *p,int k)
{
    p[k].key=k;
    p[k].parent=k;
    p[k].rank=0;
    return p;
}
int da1=0,da2=0,da3=0,da4=0;
int FindSet(struct node*p,int k)
{
    // struct node present=p[k];
    if(p[k].parent!=k)
    {
    	return FindSet(p,p[k].parent);
    }
    
    return p[k].parent;
}
int FindSet_normal_1(struct node*p,int k)
{
	da1++;
    if(p[k].parent!=k)
    {
    	
    	return FindSet_normal_1(p,p[k].parent);
    }
    
    return p[k].parent;
}
int FindSet_normal_2(struct node* p,int k)
{
    da2++;
    if(p[k].parent!=k)
    {
    	return FindSet_normal_2(p,p[k].parent);
    }
    
    return p[k].parent;
}
int FindSet_pc_3(struct node* p,int k)
{
	
    	da3++;
    if(p[k].parent!=k)
    {
    	p[k].parent=FindSet_pc_3(p,p[k].parent);
    }
    return p[k].parent;
}

int FindSet_pc_4(struct node* p,int k)
{
	da4++;
    if(p[k].parent!=k)
    {
    	
    	p[k].parent=FindSet_pc_4(p,p[k].parent);
    }
    return p[k].parent;
}
struct node* Union_without_rupc(struct node* arr1,int u,int v)
{
	int first=FindSet_normal_1(arr1,u);
	int second=FindSet_normal_1(arr1,v);
	if(first==second)
	{
		printf("%d ",first);
		return arr1;
	}
	//if(u_node->rank==v_node->rank)
	arr1[second].parent=first;
	printf("%d ",first);
	return arr1;
}
struct node* Union_only_ru(struct node* arr2,int u,int v)
{
	int first=FindSet_normal_2(arr2,u);
	int second=FindSet_normal_2(arr2,v);
	if(first==second)
	{
		printf("%d ",first);
		return arr2;
	}
	if(arr2[first].rank==arr2[second].rank)
	{
		arr2[second].parent=first;
		printf("%d ",first);
		arr2[first].rank++;
	}
	else if(arr2[first].rank>arr2[second].rank)
	{
	    arr2[second].parent=first;
	    printf("%d ",first);
	}
	else
	{
	    arr2[first].parent=second;
	    printf("%d ",second);
	}
		
	return arr2;
}
struct node* Union_only_pc(struct node* arr3,int u,int v)
{
	int first=FindSet_pc_3(arr3,u);
	int second=FindSet_pc_3(arr3,v);
	if(first==second)
	{
		printf("%d ",first);
		return arr3;
	}
	//if(u_node->rank==v_node->rank)
	arr3[second].parent=first;
	printf("%d ",first);
	//u_node->rank++;
	return arr3;
}
struct node* Union_both_rupc(struct node* arr4,int u,int v)
{
    	int first=FindSet_pc_4(arr4,u);
	int second=FindSet_pc_4(arr4,v);
	if(first==second)
	{
		printf("%d ",first);
		return arr4;
	}
	if(arr4[first].rank==arr4[second].rank)
	{
		arr4[second].parent=first;
		printf("%d ",first);
		arr4[first].rank++;
	}
	else if(arr4[first].rank>arr4[second].rank)
	{
	    arr4[second].parent=first;
	    printf("%d ",first);
	}
	else
	{
	    arr4[first].parent=second;
	    printf("%d ",second);
	}
		
	return arr4;
}
void main()
{
	char ch;
   	int k,u,v,m=10000;
	 struct node *arr1=Hash_table(arr1,m);
	 struct node *arr2=Hash_table(arr2,m);
    	 struct node *arr3=Hash_table(arr3,m);
    	 struct node *arr4=Hash_table(arr4,m);	 	
	 while(1)
	 {
		scanf(" %c",&ch);
		switch(ch)
		{
    		case 'm':scanf("%d",&k);
    			 if(arr1[k].key==-1)
    			 {
			 	arr1=make_set(arr1,k);
			 	arr2=make_set(arr2,k);
			 	arr3=make_set(arr3,k);
			 	arr4=make_set(arr4,k);
			 	printf("%d\n",arr1[k].key);
			 }
			 else
			 	printf("-1\n");
			 break;
		case 'f':scanf("%d",&k);
		        if(arr1[k].key!=-1)
    			 {
				printf("%d ",FindSet_normal_1(arr1,k));
				printf("%d ",FindSet_normal_2(arr2,k));
				printf("%d ",FindSet_pc_3(arr3,k));
				printf("%d ",FindSet_pc_4(arr4,k));
    			 }
    			 else
    			    printf("-1 -1 -1 -1");
				printf("\n");
			  break;
		case 'u':scanf("%d %d",&u,&v);
		    if(arr1[u].key==-1 || arr1[v].key==-1)
		        printf("-1 -1 -1 -1\n");
		   else
		  {
			arr1=Union_without_rupc(arr1,u,v);
			arr2=Union_only_ru(arr2,u,v);
			arr3=Union_only_pc(arr3,u,v);
			arr4=Union_both_rupc(arr4,u,v);
				printf("\n");
		  }
			
			break;
		case 's':printf("%d %d %d %d\n",da1,da2,da3,da4);
		         printf("\n");
		        exit(0);
		}
	}
}
