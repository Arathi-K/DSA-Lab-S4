#include<stdio.h>
#include<stdlib.h>
#include <string.h>
struct node
{
	int data;
	struct node* left;
	struct node* right;
	struct node* parent;
};
typedef struct node* node;
struct Tree
{
	struct node* root;
};
node CREATE_NODE(int k)
{
	node x=(node)malloc(sizeof(struct node));
	x->data=k;
	x->left=NULL;
	x->right=NULL;
	x->parent=NULL;
	return x;
}
node create_tree(char* str)
{	
	/*if(pos==0)
		now=T->root;
	else if(pos==1)
		now=now->left;
	else if(pos==2)
		now=now->right;*/
	node now;
	int bracket=0,i=0;
	if(str[i]=='(' && str[i+1]==')')
		return NULL;
	if(str[i++]=='(' && str[i]!=')')
	{
		int num=0;
			while(str[i]!='(')//&&str[i]!=')')
			{
				num=num*10+(int)str[i]-48;
				i++;
			}
			now=CREATE_NODE(num);
			//printf("%d\n",now->data);
			bracket++;
	char substring[10000];
	int j=0;
	substring[j++]=str[i++];
	while(bracket!=0)
	{
		if(str[i]=='(')	
			bracket++;
		if(str[i]==')')
			bracket--;
		substring[j++]=str[i++];
	}
	now->left=create_tree(substring);
	/*if(now->left!=NULL)
		printf("left=%d\n",now->left->data);
	else printf("leftNULL;)\n");*/
	j=0;
	substring[j++]=str[i++];
	bracket++;
	while(bracket!=0)
	{
		if(str[i]=='(')	
			bracket++;
		if(str[i]==')')
			bracket--;
		substring[j++]=str[i++];
	}
	now->right=create_tree(substring);
	/*if(now->right!=NULL)
		printf("right=%d\n",now->right->data);
	else printf("rightNULL;)\n");*/
	return now;
	}
}

node cla(node root,int a,int b)
{
   if(root==NULL)
   	return NULL;
   if(root->data==a ||root->data==b)
   	return root;
   node left=cla(root->left,a,b);
   node right=cla(root->right,a,b);
   if(left!=NULL &&right!=NULL)
   	return root;
   if(left==NULL &&right==NULL)
   	return NULL;
   if(left!=NULL && right==NULL)
   	return left;
   else
   	return right;
}
/*void INORDER(struct node* x)
{
   //printf("welcome to inorder");
    if(x!=NULL)
   {
    INORDER(x->left);
    printf("%d ",x->data);
    INORDER(x->right);
   }
   //printf("exit from inorder");
}*/
void main()
{
   char str[10000];
   int n1,n2;
   //fgets(str,10000, stdin);
    scanf("%[^\n]",str);
   scanf("%d %d",&n1,&n2);
   int l=strlen(str)-1;
   struct Tree* T=(struct Tree*)malloc(sizeof(struct Tree));
   char strwithoutspace[10000];
   int j=0;
  for(int i=0;i<l;i++)
   {
   	if(str[i]!=' ') 
   	{	
   		strwithoutspace[j]=str[i];
   		j++;
   	}
   }
  //printf("%s",strwithoutspace);
   T->root=create_tree(strwithoutspace);//PERFECT
   /*INORDER(T->root);
		        printf("\n");*/
  node now=cla(T->root,n1,n2);
  if(now!=NULL)
     printf("%d",now->data);
} 
