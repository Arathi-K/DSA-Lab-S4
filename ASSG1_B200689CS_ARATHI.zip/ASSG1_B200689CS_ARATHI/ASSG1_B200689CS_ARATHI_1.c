#include<stdio.h>
#include<stdlib.h>
struct node
{
	int key;
	struct node* right;
	struct node* left;
	struct node* parent;
	struct node* next;
};
struct BST
{
   struct node* root; 
};
struct Queue
{
	struct node* head;
	struct node* tail;
};
struct node* CREATE_NODE(int k)
{
	struct node* x=(struct node*)malloc(sizeof(struct node));
	x->key=k;
	x->right=NULL;
	x->left=NULL;
	x->parent=NULL;
	return x;
} 
int QUEUE_EMPTY(struct Queue* Q)
{
	if(Q->head==NULL)
		return -1;
	else
		return 1;
}
void ENQUEUE(struct Queue* Q,struct node* x)
{
	if(QUEUE_EMPTY(Q)==-1)
	{
	    Q->head=x;
	    Q->tail=x;
	}
	else
	{
	Q->tail->next=x;
	Q->tail=x;
	}
}
void DEQUEUE(struct Queue* Q)
{
	if(QUEUE_EMPTY(Q)!=-1)
	{
		//printf("%d\n",Q->head->key);
       	        Q->head=Q->head->next;
	}
}
void INSERT(struct BST* T,int info)
{
	struct node* keynode=CREATE_NODE(info);
	if(T->root==NULL)
	{
		T->root=keynode;
		return;
	}
	struct Queue* Q=(struct Queue*)malloc(sizeof(struct Queue));
	Q->head=NULL;
	Q->tail=NULL;
	ENQUEUE(Q,T->root);
	while(1)
	{
		struct node* now=Q->head;
		if(now->left==NULL)
		{
			now->left=keynode;
			return;
		}
		else if(now->right==NULL)
		{
			now->right=keynode;
			return;
		}	
		else
		{
			ENQUEUE(Q,now->left);
			ENQUEUE(Q,now->right);
			DEQUEUE(Q);
		}
	}
}
void PRINT(struct node* now)
{
	printf("( ");
	if(now!=NULL)
	{
	printf("%d ",now->key);
	PRINT(now->left);
	PRINT(now->right);
	}
	printf(") ");
	
}
void main()
{
	char ch;
	int info;
	struct node* present;
	struct BST* T=(struct BST*)malloc(sizeof(struct BST));
	T->root=NULL;
	//if(T->root==NULL)printf("ROOT null\n");
while(1)
	{
		scanf("%c",&ch);

		switch(ch)
		{
    		case 'i':scanf("%d",&info);
			 INSERT(T,info);
			 break;
		case 'e':exit(0);
		case 'p':PRINT(T->root);
		        printf("\n");
			 break;
		}
	}
}

