#include<stdio.h>
#include<stdlib.h>
#include <string.h>
struct node
{
	int data;
	struct node* left;
	struct node* right;
	struct node* parent;
};
typedef struct node* node;
struct Tree
{
	struct node* root;
};
node CREATE_NODE(int k)
{
	node x=(node)malloc(sizeof(struct node));
	x->data=k;
	x->left=NULL;
	x->right=NULL;
	x->parent=NULL;
	return x;
}
node create_tree(char* str)
{	
	/*if(pos==0)
		now=T->root;
	else if(pos==1)
		now=now->left;
	else if(pos==2)
		now=now->right;*/
	node now;
	int bracket=0,i=0;
	if(str[i]=='(' && str[i+1]==')')
		return NULL;
	if(str[i++]=='(' && str[i]!=')')
	{
		int num=0;
			while(str[i]!='(')//&&str[i]!=')')
			{
				num=num*10+(int)str[i]-48;
				i++;
			}
			now=CREATE_NODE(num);
			//printf("%d\n",now->data);
			bracket++;
	char substring[10000];
	int j=0;
	substring[j++]=str[i++];
	while(bracket!=0)
	{
		if(str[i]=='(')	
			bracket++;
		if(str[i]==')')
			bracket--;
		substring[j++]=str[i++];
	}
	now->left=create_tree(substring);
	/*if(now->left!=NULL)
		printf("left=%d\n",now->left->data);
	else printf("leftNULL;)\n");*/
	j=0;
	substring[j++]=str[i++];
	bracket++;
	while(bracket!=0)
	{
		if(str[i]=='(')	
			bracket++;
		if(str[i]==')')
			bracket--;
		substring[j++]=str[i++];
	}
	now->right=create_tree(substring);
	/*if(now->right!=NULL)
		printf("right=%d\n",now->right->data);
	else printf("rightNULL;)\n");*/
	return now;
	}
}
/*int checkbst(struct node* now)
{
	if(now==NULL)
		return 1;
	if(now->left!=NULL)
	{
		if(now->left->data > now->data)
		{
			now->left=NULL;
			//printf("count1\n");
			return 0;
		}
		else if(checkbst(now->left)==0) return 0;
	}
	if(now->right!=NULL)
	{
		if(now->right->data < now->data)
		{
		now->right=NULL;
		//printf("count2\n");
		return 0;
		}
		else if(checkbst(now->right)==0) return 0;
	}
	return 1;
}*/
int Smallest_data(node now)
{
if(now!=NULL)
{
	int smallest=now->data;
	//printf("smallest is %d\n",smallest);
	int a;
	if(now->left!=NULL)
	{
	a=Smallest_data(now->left);
	//printf("left is %d\n",a);
	if(a<smallest)
		smallest=a;
	}
	//printf("smallest is %d\n",smallest);
	if(now->right!=NULL)
	{
	a=Smallest_data(now->right);
	//printf("Right is %d\n",a);
	if(a<smallest)
		smallest=a;
	//	printf("smallest is %d\n",smallest);
	}
	//printf("smallest is %d\n",smallest);
	return smallest;
}
}
int Largest_data(node now)
{
if(now!=NULL)
{
	int largest=now->data;
	int a;
	if(now->left!=NULL)
	{
	 a=Largest_data(now->left);
	if(a>largest)
		largest=a;
	}
	if(now->right!=NULL)
	{
	a=Largest_data(now->right);
	if(a>largest)
		largest=a;
	//printf("%d",largest);
	}
	return largest;
}
}	

int bstcheck(node root_node)
{
    int isAbst=1;
if (root_node == NULL)
	isAbst=1;
else if (root_node->left != NULL && Largest_data(root_node->left) > root_node->data)
{
	//printf("node=%d,left=%d,largest in left=%d\n",root_node->data,root_node->left->data,Largest_data(root_node->left));
	isAbst=0;
}
else if (root_node->right != NULL && Smallest_data(root_node->right) < root_node->data)
{
	//printf("node=%d,right=%d,smallest in right=%d",root_node->data,root_node->right->data,Smallest_data(root_node->right));
	isAbst=0;
}	
else if (bstcheck(root_node->left)==0 || bstcheck(root_node->right)==0)
	isAbst=0;
//printf("returned %d",isAbst);
return isAbst;
}
void main()
{
	char str[10000];
  // fgets(str,10000, stdin);
  scanf("%[^\n]",str);
   //printf("str=%s\n",str);
   int l=strlen(str)-1;
 //   printf("....%c",str[l-1]);
   struct Tree* T=(struct Tree*)malloc(sizeof(struct Tree));
   char strwithoutspace[10000];
   int j=0;
  for(int i=0;i<l;i++)
   {
   	if(str[i]!=' ') 
   	{	
   		strwithoutspace[j]=str[i];
   		j++;
   	}
   	//printf("%c",strwithoutspace[j]);
   }
  //printf("%s",strwithoutspace);
   T->root=create_tree(strwithoutspace);
   int count=0;
   if(bstcheck(T->root) ==1)
   	count=0;
   else
   {
   if(bstcheck(T->root->left) ==0)
   {
   	T->root->left=NULL;
   	count++;
   }
   else if(T->root->left->data > T->root->data)
   {
   	T->root->left=NULL;
   	count++;
   }
   if(bstcheck(T->root->right) ==0)
   {
   	T->root->right=NULL;
   	count++;
   }
   else if(T->root->right->data < T->root->data)
   {
   	T->root->right=NULL;
   	count++;
   }
   }
   /*while(bstcheck(T->root)==0)//if it is a bst then that function will return 1
   		count++;*/
   	printf("%d",count);
}
