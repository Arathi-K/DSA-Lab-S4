#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct node{
    char* fn;
    char* ln;
    int age;
    struct node* parent;
    struct node* left;
    struct node* right;
};
struct bst{
    struct node* root;
};
struct node* CREATE_NODE(char* fn, char*ln,int age)
{
	struct node* x=(struct node*)malloc(sizeof(struct node));
	x->fn=fn;
    x->ln=ln;
    x->age=age;
	x->right=NULL;
	x->left=NULL;
	x->parent=NULL;
	return x;
} 
struct bst * Hash_table(struct bst *T, int m)
{
	int i;
	T = (struct bst*) malloc(m * sizeof(struct bst));
	for (i = 0; i < m; i++)
        {
		T[i].root = NULL;
	    }
	return T;
}
void INSERTINTOBST(struct bst* T,int h,char* s1,char*s2,int key){
    struct node* new=CREATE_NODE(s1,s2,key);
    struct node* p=NULL;
    struct node* now=T[h].root;
    while(now!=NULL)
	{
		p=now;
        if(new->age == now->age)
            return;
		if(new->age < now->age)
			now=now->left;
		else
			now=now->right;
	}
	new->parent=p;
	if(p==NULL)
		T[h].root=new;//printf("new element added as the root");
	else if (new->age < p->age)
		p->left =new;
	else p->right=new;
}

void INSERT(struct bst* T,char* s1, char* s2,int age){
    int sum=0,h=0;
    //printf("Your name is %s %s, age is %d\n", s1,s2,age);
    for(int i=0;i<strlen(s2);i++)
         {  
             sum=sum+(int)s2[i];
            // printf("s2[i]=%c with ascii value %d",s2[i],(int)s2[i]);
         }
        h=sum%128; 
      //   printf("h is %d and s2[i]=%s\n",h,s2);
    INSERTINTOBST(T,h,s1,s2,age);
    //printf("inserted %s %s at T[%d]\n",s1,s2,h);
    //printf("T[%d].root=%s %s of age %d\n",h,T[h].root->fn,T[h].root->ln,T[h].root->age);
}
void PRINTrelatives(struct node* root,int key){

    if(root!=NULL)
    {
     printf("%s %s %d\n",root->fn,root->ln,root->age);
     if(root->age==key)
                return;
     if(key< root->age)
            PRINTrelatives(root->left,key);
    else if(key> root->age)
            PRINTrelatives(root->right,key);
    }
}
int count=0;
int SEARCH_AGE(struct node* root,char firstname[],char lastname[])
{

    // printf("\n..Trot->name and age= ...%s....%s...%d...ooo",root->fn,root->ln,root->age);
    // printf("%dst counting :",count);
    // count++ ;
    int a;
    if(root==NULL){
        //printf("NULL\n");
	 a=-1;
    }
    if(root!=NULL)
    {
        a=-1;
        //printf("\n..root->name and age= ...%s....%s...%d...ooo, fn=%s,sn=%s",root->fn,root->ln,root->age,firstname,lastname);
        //printf("root fn=%ld fn=%ld root ln=%ld ln=%ld\n ",strlen(root->fn),strlen(firstname),strlen(root->ln),strlen(lastname));
        if(strcmp(root->fn,firstname)==0 && strcmp(root->ln,lastname)==0){		
	    //printf("root->age...%d\n",root->age); 
     	    a=root->age;
        }
        else{
            if(root->left!=NULL)
                a= SEARCH_AGE(root->left,firstname,lastname);
            if(a==-1)
            {
            if(root->right!=NULL)
             a= SEARCH_AGE(root->right,firstname,lastname);
            }
        }
    }
    return a;
}
int main(){
char ch;
// hash table size is 128
int m=128;
char fn[1000][1000],sn[1000][1000];
int age,h,b=0;
struct bst *T=Hash_table(T,m);
int sum=0,i;
while(1)
	{
         
	 //  printf("enter a character");
		scanf(" %c",&ch);
		switch(ch)
		{	
		case 'i':
		        //printf("enter the name and age\n");
		         scanf("%s", fn[b]);
               // printf("enter a string\n");
                    scanf("%s", sn[b]);
                 //printf("enter age\n");
				 scanf("%d",&age);
				INSERT(T,fn[b],sn[b],age);
               //  printf("T[108].root=%s %s of age %d\n",T[108].root->fn,T[108].root->ln,T[108].root->age);
                // printf("Your name is %s %s, age is %d\n", fn[b],sn[b],age);
                b++;
				break;
		case 'p':
	        	//printf("enter a first name and last name");
                scanf(" %s", fn[b]);
                scanf(" %s", sn[b]);
                //printf("the name is %s %s",fn[b],sn[b]);
                h=0,sum=0;
                // printf("%c",s2[0]);
                for(i=0;i<strlen(sn[b]);i++)
                {  
                  sum=sum+(int)sn[b][i];
                //   printf("s2[i]=%c with ascii value %d",s2[i],(int)s2[i]);
                }
                  h=sum%128; 
                 // printf("h is%d \n",h);
                 // printf("T.root->name and age=%s %s %d\n",T[h].root->fn,T[h].root->ln,T[h].root->age);
                  age=SEARCH_AGE(T[h].root,fn[b],sn[b]);
                  //printf("age is %d \n",age);
                   if(age!=-1)
				   PRINTrelatives(T[h].root,age);
                   else
                     printf("-1\n");
                 b++;
				break;
		case 't':exit(0);
		}
       // printf("T[108].root=%s %s of age %d\n",T[108].root->fn,T[108].root->ln,T[108].root->age);
	}
    return 0;
}
