#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct slot 
{
	int key;
	char* name;
};
struct slot * Hash_table(struct slot *T, int m)
{
	int i;
	T = (struct slot*) malloc(m * sizeof(struct slot));
	for (i = 0; i < m; i++) 
        {
		T[i].key = -1;
	}
	// for (i = 0; i < m; i++) 
    //     {
	// 	printf("%d ",T[i].key);
	// 	printf("%d \n",T[i].value);
	// }
	return T;
}
void INSERT(struct slot * T,int h,char* str)
{
	T[h].name=str;
	T[h].key=h;
}
int Calculate_rollnum(char string[])
{int a=0,b=0,c=0;
    int ha=0,hb=0,hc=0;
    int roll=0;
    for(int i=0;i<strlen(string);i++)
    {
        if(i==0||i==1||i==2)
            a=a+(int)string[i];
        if(i==0||i==2||i==4)
            b=b+(int)string[i];
        if(i==0||i==4||i==8)
            c=c+(int)string[i];
    }
    ha=(a%26)%10;
    hb=(b%26)%10;
    hc=(c%26)%10;
    roll=(ha*100)+(hb*10)+(hc);
    return roll;
}
int integernum(char* rollnum)
{
    int sum=0;
    for(int i=1;i<strlen(rollnum);i++)
    {
        sum=(sum*10)+(int)rollnum[i]-48;
       // printf("sum is %d\n",sum);
    }
   // printf("sum is %d\n",sum);
    return sum;
}
// void PRINT(struct slot * T)
// {
// 	for(int i=0;i<1000;i++)
// 	{
//         if(T[i].key != -1)
//         {
// 		printf("%d ",i);
// 		printf("(");
// 		if(T[i].key != -1)
// 		printf("%d %s",T[i].key,T[i].name);
// 		printf(")\n");
//         }
// 	}
// }
void main()
{
    char ch;
    char string[1000][1000];
    int m=1000;
    struct slot *T=Hash_table(T,m);
    int h=0,b=0;
    char rollnum[7];
    while(1)
    {
        scanf(" %c",&ch);
        switch (ch)
        {
        case 'i':scanf("%s", string[b]);
            //      PRINT(T);
            //    printf("\n");
                h=Calculate_rollnum(string[b]);
               // printf("roll num=%c%d and ",string[b][0],h);
                INSERT(T,h,string[b]);
               // printf("T[h].name=%s\n",T[h].name);
            //    PRINT(T);
            //    printf("\n");
                b++;
            break;
        case 's':scanf("%s", rollnum);
                h=integernum(rollnum);
                if(h<999){
            //     PRINT(T);
            //    printf("\n");
                if(T[h].key==-1)
                    printf("NOT FOUND\n");
                else if(T[h].name[0]==rollnum[0])
                    printf("%s\n",T[h].name);
                else
                    printf("NOT FOUND\n");
                // printf("%c ,%c ",T[h].name[0],rollnum[0]);
                }

            break;
        case 'd':
                scanf("%s", rollnum);
                //printf("%s", rollnum);
                h=integernum(rollnum);
                if(h<999)
                {
                // PRINT(T);
                //  printf("\n");
                //printf("%c ,%c ",T[h].name[0],rollnum[0]);
                if(T[h].key!=-1)
                {   
                    if(T[h].name[0]==rollnum[0])
                    T[h].key=-1;
                }
                }
            break;
        case 't':exit(0);
        }
    }
}
