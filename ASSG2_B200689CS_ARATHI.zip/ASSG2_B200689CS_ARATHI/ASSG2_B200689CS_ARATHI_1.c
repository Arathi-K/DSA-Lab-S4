#include<stdio.h>
#include<stdlib.h>
 
struct slot 
{
	int key;
	int value;
};
struct slot * Hash_table(struct slot *T, int m)
{
	int i;
	T = (struct slot*) malloc(m * sizeof(struct slot));
	for (i = 0; i < m; i++) 
        {
		T[i].key = -1;
		T[i].value = -1;
	}
	// for (i = 0; i < m; i++) 
    //     {
	// 	printf("%d ",T[i].key);
	// 	printf("%d \n",T[i].value);
	// }
	return T;
}
int check_if_occupied(struct slot *T,int key)
{
	//printf("T[key].key is %d,T[key].value=%d\n",T[key].key,T[key].value);
	if(T[key].key==-1)
		return -1;
	else 
		return 1;
	// return 0;
    
}
int SEARCH(struct slot *T,int m,int key)
{
	for (int i = 0; i < m; i++) 
    {
		if(T[i].key !=-1)
		{
			if(key==T[i].value)
					return T[i].key;
		}
	}
	return -1;
}
int IS_PRIME(int n)
{
	for(int i=2;i<n/2;i++)
	{
		if(n%i ==0)
			return -1;
	}
	return 1;
}
int Largest_Prime(int m)
{
	for(int i=m-1;i>=2;i--)
	{
		if(IS_PRIME(i)==1)
				return i;
	}
}
void INSERT(struct slot * T,int h,int k)
{
	T[h].value=k;
	T[h].key=h;
}
struct slot * DELETE(struct slot *  T,int m,int k)
{
	int index=SEARCH(T,m,k);
	T[index].key= -1;
	return T;
}
void PRINT(struct slot * T,int m)
{
	for(int i=0;i<m;i++)
	{
		printf("%d ",i);
		printf("(");
		if(T[i].key != -1)
		printf("%d",T[i].value);
		printf(")\n");
	}
}
void main()
{
	char ch,option;
	scanf("%c",&ch);
	int m,k,c1,c2,h,i,h1,h2,R=0;
	scanf("%d",&m);
	struct slot *T=Hash_table(T,m);
	// for (i = 0; i < m; i++) 
    //     {
	// 	printf("%d ",T[i].key);
	// 	printf("%d \n",T[i].value);
	// }
	if(ch=='a')
	{
		//printf("enter c1 and c2");
		scanf("%d %d",&c1,&c2);
	}
	else if(ch=='b')
	{
		R =Largest_Prime(m);
		//printf("R=%d\n",R);
	}
	while(1)
	{
		scanf(" %c",&option);
		switch(option)
		{	
		case 'i':
			     scanf("%d", &k);
				// printf("k is %d",k);
	// 			 for (i = 0; i < m; i++) 
    //     {
	// 	printf("%d ",T[i].key);
	// 	printf("%d \n",T[i].value);
	// }
				if(ch=='a')
				{
					i=-1;
					do{
					i++;
					h=((k%m)+(c1*i)+(c2*i*i))%m;
					//printf("h is %d",h);
					}while(check_if_occupied(T,h)==1&& i<m);
					//printf("h is %d",h);
					if(T[h].key==-1)
						INSERT(T,h,k);
				}
				else if(ch=='b')
				{
					 h1 = k%m;
					 h2 = R-(k % R); 
					 i=-1;
					 do{
						i++;
						h= (h1 + (i*h2))% m;
						//	printf("h is %d",h);
					}while(check_if_occupied(T,h)==1 && i<m);
					if(T[h].key==-1)
						INSERT(T,h,k);
				}
				// 					 for (i = 0; i < m; i++) 
       		    // {
				// 	printf("%d ",T[i].key);
				// 	printf("%d \n",T[i].value);
				// }
				break;
		case 's':
				scanf("%d",&k);
				if(SEARCH(T,m,k)== -1)
						printf("-1\n");
				else
						printf("1\n");
				break;
		case 'd':
				scanf("%d",&k);
				T=DELETE(T,m,k);
				// 	 for (i = 0; i < m; i++) 
       		    // {
				// 	printf("%d ",T[i].key);
				// 	printf("%d \n",T[i].value);
				// }
				break;
		case 'p':
				PRINT(T,m);
				break;
		case 't':       exit(0);
		}
	}
}