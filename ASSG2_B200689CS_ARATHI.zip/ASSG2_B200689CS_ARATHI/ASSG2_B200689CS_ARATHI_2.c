#include<stdio.h>
#include<stdlib.h>
#include <string.h>

struct node{
char *word;
struct node *next; 
};

struct LL
{
	struct node* head;
};

struct node* CREATENODE(char str[]){
    struct node* new=(struct node*)malloc(sizeof(struct node));
    new->word=str;
    new->next=NULL;
    return new;
}

void PRINT(struct LL* T,int m){
	for(int i=0;i<m;i++)
	{
		printf("%d:",i);
		if(T[i].head==NULL)
			printf("null");
	    else{
			struct node* now=T[i].head;
			printf("%s",now->word);
			while(now->next!=NULL){
				now=now->next;
				printf("-%s",now->word);
			}
		}
		printf("\n");
	}
}

int SEARCH(struct node* now,char str[])//checks if the string is present in this specific LL
{
   //  printf("str=%s, now->word=%s\n",str,now->word);
	if(strcmp(now->word,str)==0)
		return 1;
	while(now->next!=NULL)
	{
		now=now->next;
		//printf("str=%s, now->word=%s\n",str,now->word);
		if(strcmp(now->word,str)==0)
			return 1;
	}
	return 0;
}

struct LL * Hash_table(struct LL *T, int m)
{
	int i;
	T = (struct LL*) malloc(m * sizeof(struct LL));
	for (i = 0; i < m; i++)
        {
		T[i].head = NULL;
	    }
	return T;
}

void INSERT(struct LL* T,int m,int h,char str[]){
	// printf("table inside INSERT %d\n", h);
	// printf("String is %s\n",str);
 		if(T[h].head ==NULL){
			// printf("T.head at %d is null\n",h);
			T[h].head=CREATENODE(str);
			return;
		}
	 if(SEARCH(T[h].head,str)==1)
	 {
	 	// printf("element is already present\n");
	 	return;
	 }
	struct node* x=CREATENODE(str);
	struct node* nowat= T[h].head;
    if(nowat!=NULL)
    {  
        while(nowat->next!=NULL)
            nowat=nowat->next;
        nowat->next=x;
    }
}

void main()
{
		int m;
		scanf("%d",&m);
		char str[500],substring[500][500];
		// printf("Enter a string\n");
		scanf(" %[^\n]",str);
		// printf("string is %s\n",str);
		int l=strlen(str);
		struct LL *T=Hash_table(T,m);
		int h,j=0,i=0,b=0;
	  	while(i<l)
		{
			// printf("starting\n");
			// PRINT(T,m);
			// printf("\n");
			j=0;
		    	if(str[i]!=' ')
		    	{
				// printf("i is %d\n",i);
				while(str[i]!=' ' && i<l)
		    		{
					// printf("loop %d \n",i);
					// PRINT(T,m);
					// printf("\n");

		        		substring[b][j]=str[i];
					j++;
					i++;
		        	}
				substring[b][j]='\0';
				h= ((j)*(j))%m;
				// printf("String is 3.. %s\n",substring[b]);
				INSERT(T,m,h,substring[b]);
				b++;
		   		i++;
				}
		}
		PRINT(T,m);
}
