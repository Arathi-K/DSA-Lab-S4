#include<stdio.h>
#include<stdlib.h>
//#include <string.h>

struct node{
int key;
struct node *next; 
};

struct LL
{
	struct node* head;
};

struct node* CREATENODE(int k){
    struct node* new=(struct node*)malloc(sizeof(struct node));
    new->key=k;
    new->next=NULL;
    return new;
}
struct LL * Hash_table(struct LL *T, int m)
{
	int i;
	T = (struct LL*) malloc(m * sizeof(struct LL));
	for (i = 0; i < m; i++)
        {
		T[i].head = NULL;
	    }
	return T;
}
void INSERT(struct LL* T,int h,int k){
 		if(T[h].head ==NULL){
			T[h].head=CREATENODE(k);
			return;
		}
    struct node* x=CREATENODE(k);
    struct node* nowat= T[h].head;
    if(nowat!=NULL)
    {  
        while(nowat->next!=NULL)
            nowat=nowat->next;
        nowat->next=x;
    }
}
void PRINT(struct LL* T,int m){
	for(int i=0;i<m;i++)
	{
		printf("%d ",i);
		if(T[i].head!=NULL)
		{
			struct node* now=T[i].head;
			printf("%d ",now->key);
			while(now->next!=NULL){
				now=now->next;
				printf("%d ",now->key);
			}
		}
		printf("\n");
	}
}
void main()
{
		int n,k;
		scanf("%d",&n);
		struct LL *T=Hash_table(T,n);
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				scanf("%d",&k);
				if(k==1)
					INSERT(T,i,j);
			}
		}
		PRINT(T,n);		
}

