#include<stdio.h>
#include<stdlib.h>

struct node {
	int u;
	int v;
	int wt;
};
void main()
{
	int n_v,n_e,i,j,a,b,w;
	scanf("%d %d",&n_v,&n_e);
	
	struct node* edge_arr =(struct node*)malloc(n_e*sizeof(struct node));
	for(i=0;i<n_e;i++)
		scanf("%d %d %d",&edge_arr[i].u,&edge_arr[i].v,&edge_arr[i].wt);
		
	int* dist=(int*)malloc(n_v*sizeof(int));
	for(int i=1;i<n_v;i++)
		dist[i]=9999;
	dist[0]=0;
	
	for(i=0;i<n_v;i++)
	{
		for(j=0;j<n_e;j++)
		{
			a=edge_arr[j].u;
			b=edge_arr[j].v;
			w=edge_arr[j].wt;
			if(dist[a]+w<dist[b])
				dist[b]=dist[a]+w;
		}
	}
	for(j=0;j<n_e;j++)
		{
			a=edge_arr[j].u;
			b=edge_arr[j].v;
			w=edge_arr[j].wt;
			if(dist[a]+w<dist[b])
			{
				printf("1\n");
				exit(0);
			}
		}
	printf("-1\n");
}
