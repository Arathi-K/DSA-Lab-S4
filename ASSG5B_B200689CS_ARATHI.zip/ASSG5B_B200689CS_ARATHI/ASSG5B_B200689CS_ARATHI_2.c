#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct node{
int wt;
int u;
int v;
};
struct vertex_node{
int key;
int parent;
int rank;
};
struct vertex_node* Hash_table(struct vertex_node *p, int m)
{
	int i;
	p = (struct vertex_node*) malloc(m * sizeof(struct vertex_node));
	for (i = 0; i < m; i++) 
        {
		p[i].key = -1;
	}
	return p;
}
struct node* sort(struct node* arr,int n)
{
	int i,j;
	struct node temp;
	for (i = 0; i < n; ++i) 
        {
            for (j = i + 1; j < n; ++j)
            {
                if (arr[i].wt > arr[j].wt) 
                {
                    temp=  arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
        return arr;
}
 struct vertex_node* make_set(struct vertex_node *p,int k)
{
    p[k].key=k;
    p[k].parent=k;
    p[k].rank=0;
    return p;
}
int findSet(struct vertex_node*p,int k)
{
    // struct node present=p[k];
    if(p[k].parent!=k)
    {
    	return findSet(p,p[k].parent);
    }
    
    return p[k].parent;
}
struct node* insert(struct node* arr,int index,int wt,int u,int v)
{
    arr[index].wt=wt;
    arr[index].u=u;
    arr[index].v=v;
    
    return arr;
}
struct vertex_node* Union(struct vertex_node* arr1,int u,int v)
{
	int first=findSet(arr1,u);
	int second=findSet(arr1,v);
	arr1[second].parent=first;
	return arr1;
}
void Kruskals_algo()
{
    int n,i,u,num,n_e,index=0,output=0;
    char str[9999];
		scanf("%d",&n);
		struct node* arr=(struct node*)malloc(10000*sizeof(int));
       for(int k=0;k<n;k++)
       {
         
           scanf("%d",&u); 
            scanf(" %[^\n]",str);
            int l=strlen(str);
    	    i=0;
	        while(i<l)
		    {
		        if(str[i]!=' ')  
		        {
			    num = 0;
			    while(str[i]!=' ' && i<l)
			    {	      
		        num = num*10 +((int)str[i]-48);
		        i++;
		        }
		       
		        arr=insert(arr,index,-1,u,num);
		        index++;
		        }
		   i++;
		   }

       }
       n_e=index;
       index=0;
       for(int k=0;k<n;k++)
       {
         
           scanf("%d",&u); 
            scanf(" %[^\n]",str);
            int l=strlen(str);
    	    i=0;
	        while(i<l)
		    {
		        if(str[i]!=' ')  
		        {
			    num = 0;
			    while(str[i]!=' ' && i<l)
			    {	      
		        num = num*10 +((int)str[i]-48);
		        i++;
		        }
		      // printf("arr[%d].wt= %d\n",index,num);
		        arr[index].wt=num;
		        index++;
		        }
		   i++;
		   }

       }
       
       arr=sort(arr,n_e);
    //   for(int m=0;m<n_e;m++)
    //   {
    //       printf("arr[%d].wt= %d\n",m,arr[m].wt);
    //   }
      struct vertex_node *par=Hash_table(par,n);
      for(i=0;i<n;i++)
      	par=make_set(par,i);
    //   	printf("n_e=%d\n",n_e);
      	for(i=0;i<n_e;i++)
         {	
        //   printf("i=%d\n",i);
        //   printf("findSet(par,arr[i].u)=%d,findSet(par,arr[i].v)=%d",findSet(par,arr[i].u),findSet(par,arr[i].v));
      		if(findSet(par,arr[i].u)!=findSet(par,arr[i].v))
      		{
      		    
      		    // printf("accepted %d\n",i);
      		par=Union(par,arr[i].u,arr[i].v);
      		output=output+arr[i].wt;

      		}	
      }
      printf("%d\n",output);
}
void main()
{
	char ch;
		scanf(" %c",&ch);
		switch(ch)
		{
    		case 'a':Kruskals_algo();
    		        break;
    	    case 'b':Kruskals_algo();
    	           break;
		}
} 
    

       


